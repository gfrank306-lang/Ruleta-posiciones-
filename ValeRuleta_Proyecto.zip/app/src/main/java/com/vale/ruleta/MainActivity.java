package com.vale.ruleta;

import android.app.*;import android.os.*;import android.graphics.*;import android.graphics.drawable.*;import android.view.*;import android.widget.*;import android.content.*;import java.io.*;import java.util.*;

public class MainActivity extends Activity {
  WheelView wheel; Spinner day, month;
  @Override public void onCreate(Bundle b){super.onCreate(b); getWindow().setStatusBarColor(Color.BLACK);getWindow().setNavigationBarColor(Color.BLACK);
    FrameLayout root=new FrameLayout(this); root.setBackgroundColor(Color.BLACK); wheel=new WheelView(this); root.addView(wheel,new FrameLayout.LayoutParams(-1,-1));
    day=spinner(new String[]{"Selecciona un día","1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30","31"});
    month=spinner(new String[]{"Selecciona un mes","Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"});
    root.addView(day);root.addView(month);setContentView(root); root.post(()->placeSpinners()); }
  Spinner spinner(String[] a){Spinner s=new Spinner(this); ArrayAdapter<String> ad=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,a){public View getView(int p,View v,android.view.ViewGroup g){TextView t=(TextView)super.getView(p,v,g);t.setTextColor(Color.WHITE);t.setTextSize(16);t.setGravity(Gravity.CENTER_VERTICAL);t.setPadding(16,0,8,0); GradientDrawable bg=new GradientDrawable();bg.setColor(Color.rgb(18,18,18));bg.setCornerRadius(12);bg.setStroke(3,Color.BLACK);t.setBackground(bg);return t;}};s.setAdapter(ad);s.setPopupBackgroundDrawable(new ColorDrawable(Color.DKGRAY));return s; }
  void placeSpinners(){int w=wheel.getWidth(),h=wheel.getHeight(), size=Math.min(w,h), left=(w-size)/2; int x=left+(int)(size*.342), width=(int)(size*.292), hgt=(int)(size*.061); FrameLayout.LayoutParams a=new FrameLayout.LayoutParams(width,hgt);a.leftMargin=x;a.topMargin=(int)(size*.422)+(h-size)/2;day.setLayoutParams(a); FrameLayout.LayoutParams c=new FrameLayout.LayoutParams(width,hgt);c.leftMargin=x;c.topMargin=(int)(size*.55)+(h-size)/2;month.setLayoutParams(c); }
  class WheelView extends View {Bitmap base,blue,red;float rb=0,rr=0,lastAngle;int active=0;Paint p=new Paint(3);float cx,cy;
    WheelView(Context c){super(c);try{base=load("base.png");blue=load("blue.png");red=load("red.png");}catch(Exception e){}}
    Bitmap load(String n)throws Exception{return BitmapFactory.decodeStream(getAssets().open(n));}
    protected void onDraw(Canvas c){super.onDraw(c);float s=Math.min(getWidth(),getHeight())/1254f;cx=getWidth()/2f;cy=getHeight()/2f;c.save();c.translate(cx,cy);c.scale(s,s);p.setFilterBitmap(true);c.drawBitmap(base,-627,-627,p);c.save();c.rotate(rb);c.drawBitmap(blue,-627,-627,p);c.restore();c.save();c.rotate(rr);c.drawBitmap(red,-627,-627,p);c.restore();c.restore();}
    float ang(float x,float y){return (float)Math.toDegrees(Math.atan2(y-cy,x-cx));}
    public boolean onTouchEvent(android.view.MotionEvent e){float d=(float)Math.hypot(e.getX()-cx,e.getY()-cy); if(e.getAction()==0){if(d>515*(Math.min(getWidth(),getHeight())/1254f)){active=1;lastAngle=ang(e.getX(),e.getY());return true;} if(d>295*(Math.min(getWidth(),getHeight())/1254f)){active=2;lastAngle=ang(e.getX(),e.getY());return true;} } else if(e.getAction()==2&&active!=0){float a=ang(e.getX(),e.getY()),delta=a-lastAngle;if(delta>180)delta-=360;if(delta<-180)delta+=360;if(active==1)rb+=delta;else rr+=delta;lastAngle=a;invalidate();return true;} else if(e.getAction()==1||e.getAction()==3){active=0;return true;}return true; }
  }
}
